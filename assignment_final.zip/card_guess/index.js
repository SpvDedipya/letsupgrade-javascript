//cards

let cards=[
    {
        image:"https://th.bing.com/th/id/OIP.JeAZLvfTqILfm33nAmpmEwHaGZ?pid=ImgDet&rs=1",
        value:1,
        status:"closed",
    },
    {
        image: "https://th.bing.com/th/id/OIP.JeAZLvfTqILfm33nAmpmEwHaGZ?pid=ImgDet&rs=1",
        value: 1,
        status: "closed",
    },
    {
        image: "https://edge.alluremedia.com.au/uploads/businessinsider/2015/02/thor-temple.jpg",
        value: 2,
        status: "closed",
    },
    {
        image: "https://edge.alluremedia.com.au/uploads/businessinsider/2015/02/thor-temple.jpg",
        value: 2,
        status: "closed",
    },
    {
        image: "https://th.bing.com/th/id/OIP.13pRFDrVC4Dj3soNe4HrPQHaJO?pid=ImgDet&rs=1",
        value: 3,
        status: "closed",
    },

    {
        image: "https://th.bing.com/th/id/OIP.13pRFDrVC4Dj3soNe4HrPQHaJO?pid=ImgDet&rs=1",
        value: 3,
        status: "closed",
    },

    {
        image: "https://moviescounnter.com/wp-content/uploads/2020/01/7122170865_542995ccaf_b.jpg",
        value: 4,
        status: "closed",
    },

    {
        image: "https://moviescounnter.com/wp-content/uploads/2020/01/7122170865_542995ccaf_b.jpg",
        value: 4,
        status: "closed",
    },


    {
        image: "https://th.bing.com/th/id/OIP.juCzaADTSHVSjCQOhWVAcAHaEo?pid=ImgDet&rs=1",
        value: 5,
        status: "closed",
    },
    {
        image: "https://th.bing.com/th/id/OIP.juCzaADTSHVSjCQOhWVAcAHaEo?pid=ImgDet&rs=1",
        value: 5,
        status: "closed",
    },
    {
        image: "https://th.bing.com/th/id/R.732f125f23c524f6df6f22a53be22a6c?rik=8PZNIT3LLNbhvw&riu=http%3a%2f%2fwww.vignette2.wikia.nocookie.net%2fmarvelmovies%2fimages%2f7%2f78%2fAvengers_age_of_ultron_hulk-art.jpg%2frevision%2flatest%2fscale-to-width-down%2f2000%3fcb%3d20160512192747&ehk=CLQ%2bXmF%2fDGX2UVy9J00tNcVB6WJXyPqcjfj4fuxYMUM%3d&risl=&pid=ImgRaw",
        value: 6,
        status: "closed",
    },
    {
        image: "https://th.bing.com/th/id/R.732f125f23c524f6df6f22a53be22a6c?rik=8PZNIT3LLNbhvw&riu=http%3a%2f%2fwww.vignette2.wikia.nocookie.net%2fmarvelmovies%2fimages%2f7%2f78%2fAvengers_age_of_ultron_hulk-art.jpg%2frevision%2flatest%2fscale-to-width-down%2f2000%3fcb%3d20160512192747&ehk=CLQ%2bXmF%2fDGX2UVy9J00tNcVB6WJXyPqcjfj4fuxYMUM%3d&risl=&pid=ImgRaw",
        value: 6,
        status: "closed",
    },
];

//shuffling algorithm

let temp;
for(let i=cards.length-1;i>=0;i--)
{
    let j=Math.floor(Math.random()*(i+1));
    temp=cards[i];
    cards[i]=cards[j];
    cards[j]=temp;
}
console.log(cards);

function displayCards(data){
    let cardsString="";

    data.forEach(function(card,index){
        cardsString +=`
        <div class="card" style="background-image:url('${card.image}')">
        <div class="overlay ${card.status}" onclick="openCard(${index})">
        </div>
        </div>
        `;
    });
    document.getElementById('cards').innerHTML = cardsString;
}
displayCards(cards);

let cardsCopy=cards;
let cardCount=1;
let score=0;
let val1=null,val2=null;
function openCard(index){
    cards[index].status="opened";
    if(cardCount===1){
        val1=cards[index].value;
        cardCount++;
    }
    else if(cardCount==2){
        val2=cards[index].value;
        
        if(val1===val2){
            score++;
            document.getElementById("score").innerHTML=score;

            //reset values
            val1 = null;
            val2 = null;
            cardCount=1;
        }
        else{
            alert("game over");
           location.reload();
        }
    }
    displayCards(cards);
}